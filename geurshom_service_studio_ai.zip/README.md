# GEURSHOM SERVICE STUDIO — AI VERSION

## Ibirimo
- Firebase Email/Password Login & Register
- Firestore movies
- VIP 300 RWF / 7 days
- VIP request system
- Google Drive online player
- Download (VIP)
- Search
- AI Assistant mu Kinyarwanda
- AI recommendations
- Dynamic/static ads
- Responsive kuri phone na PC

## 1. Firebase
Muri `public/app.js`, hindura:
YOUR_API_KEY
YOUR_PROJECT
YOUR_PROJECT_ID
YOUR_MSG_ID
YOUR_APP_ID

Muri Firebase Console:
- Enable Authentication > Email/Password
- Create Firestore Database

Collections:
`movies`
fields:
title, genre, translator, driveId, vip, uploadedAt

`vip_requests`
fields:
uid, email, status, createdAt

`vip_users`
document ID = Firebase user UID
fields:
email, expiresAt

## 2. AI
Ntushyire OpenAI API key muri HTML cyangwa JS yo muri browser.

Kora:
npm install

Copy `.env.example` muri `.env`, hanyuma:
OPENAI_API_KEY=...
OPENAI_MODEL=gpt-5-mini

Tangira:
npm start

Fungura:
http://localhost:3000

## 3. Google Drive
Drive file igomba kuba accessible ku bantu bemerewe kuyireba. Shyira file ID muri `movies.driveId`.

## 4. IMPORTANT
VIP payment iri muri iyi version ikora nka `payment request`; admin ni we wemeza ko amafaranga yoherejwe hanyuma agashyira user muri `vip_users` afite `expiresAt`.
MoMo automatic payment ntirimo kubera ko bisaba credentials/API configuration ya payment provider.
