require("dotenv").config();
const express=require("express");
const path=require("path");

const app=express();
app.use(express.json({limit:"1mb"}));
app.use(express.static(path.join(__dirname,"public")));

app.post("/api/ai",async(req,res)=>{
  try{
    if(!process.env.OPENAI_API_KEY){
      return res.status(500).json({reply:"OPENAI_API_KEY ntabwo yashyizwe muri .env."});
    }
    const {message,movies=[]}=req.body;
    const movieText=movies.map(m=>`- ${m.title} | genre: ${m.genre||"unknown"} | umusobanuzi: ${m.translator||"unknown"} | VIP: ${m.vip?"yego":"oya"}`).join("\n");
    const system=`Uri Geurshom AI Assistant wa Geurshom Service Studio. Subiza mu Kinyarwanda cyumvikana, ugire urugwiro kandi usubize mu buryo bugufi ariko bufite akamaro.
Ufasha abakoresha: gushaka no guhitamo film, gusobanura genres, recommendation, uko VIP ikora, n'ibibazo rusange bya website.
Niba ubajijwe film, koresha urutonde rwatanzwe gusa kandi ntuhimbe film itarimo.
VIP: 300 RWF / 7 days, payment request ikorerwa kuri website.
FILMS:
${movieText}`;

    const response=await fetch("https://api.openai.com/v1/responses",{
      method:"POST",
      headers:{
        "Content-Type":"application/json",
        "Authorization":"Bearer "+process.env.OPENAI_API_KEY
      },
      body:JSON.stringify({
        model:process.env.OPENAI_MODEL||"gpt-5-mini",
        instructions:system,
        input:message,
        max_output_tokens:500
      })
    });
    const data=await response.json();
    if(!response.ok) throw new Error(data.error?.message||"AI request failed");
    res.json({reply:data.output_text||"Nta gisubizo nabonye."});
  }catch(e){
    console.error(e);
    res.status(500).json({reply:"Habaye ikibazo kuri AI. Ongera ugerageze nyuma."});
  }
});

const PORT=process.env.PORT||3000;
app.listen(PORT,()=>console.log(`Geurshom Service Studio running on http://localhost:${PORT}`));
