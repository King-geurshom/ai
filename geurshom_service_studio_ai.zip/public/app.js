// ================= GEURSHOM SERVICE STUDIO =================
// 1) Shyiramo Firebase config ya project yawe.
// 2) AI ntishyira API key muri browser; browser ivugana na /api/ai.
// 3) Server ya Node.js ni yo ibika OPENAI_API_KEY muri .env.

const firebaseConfig = {
  apiKey: "YOUR_API_KEY",
  authDomain: "YOUR_PROJECT.firebaseapp.com",
  projectId: "YOUR_PROJECT_ID",
  storageBucket: "YOUR_PROJECT.appspot.com",
  messagingSenderId: "YOUR_MSG_ID",
  appId: "YOUR_APP_ID"
};

firebase.initializeApp(firebaseConfig);
const auth=firebase.auth();
const db=firebase.firestore();
let currentUser=null;
let movies=[];

const $=id=>document.getElementById(id);

async function register(){
  try{
    await auth.createUserWithEmailAndPassword($("email").value.trim(),$("password").value);
    alert("Account yakozwe neza!");
  }catch(e){alert(e.message)}
}
async function login(){
  try{
    const r=await auth.signInWithEmailAndPassword($("email").value.trim(),$("password").value);
    currentUser=r.user;
    $("loginBox").classList.add("hidden");
    $("app").classList.remove("hidden");
    await loadMovies();
    await checkVIP();
  }catch(e){alert(e.message)}
}
function logout(){auth.signOut().then(()=>location.reload())}

async function loadMovies(){
  try{
    const snap=await db.collection("movies").orderBy("uploadedAt","desc").get();
    movies=snap.docs.map(d=>({id:d.id,...d.data()}));
  }catch(e){
    // Demo movies if Firestore has not been configured yet.
    movies=[
      {title:"Rocky Kimono – Film 1",genre:"Action",translator:"Rocky Kimono",driveId:"FILE_ID_1",vip:true},
      {title:"Gaheza Simba – Film 2",genre:"Drama",translator:"Gaheza Simba",driveId:"1R-_fjLA9c-NzAlADhV3I84yoH-Hqjwem",vip:false},
      {title:"Saga Mwiza – Film 3",genre:"Drama",translator:"Saga Mwiza",driveId:"FILE_ID_2",vip:true}
    ];
  }
  renderMovies(movies);
}

function renderMovies(list){
  $("moviesContainer").innerHTML=list.map((m,i)=>`
    <div class="movie-card movie">
      <h3>${escapeHtml(m.title||"Film")}</h3>
      <span class="badge">${escapeHtml(m.genre||"Unknown")}</span>
      <p class="muted">🎙️ ${escapeHtml(m.translator||"Geurshom")}</p>
      ${m.vip?'<span class="lock">🔒 VIP</span>':'<span class="badge">FREE</span>'}
      <br>
      <button class="primary" onclick="watchMovie('${safe(m.driveId)}',${!!m.vip})">▶️ Reba Online</button>
      ${m.vip?`<button class="gold" onclick="downloadVIP('${safe(m.driveId)}')">⬇️ Download VIP</button>`:
      `<button class="green" onclick="downloadMovie('${safe(m.driveId)}')">⬇️ Download</button>`}
    </div>`).join("");
}

function filterMovies(){
  const q=$("searchInput").value.toLowerCase();
  renderMovies(movies.filter(m=>
    `${m.title||""} ${m.genre||""} ${m.translator||""}`.toLowerCase().includes(q)
  ));
}

async function checkVIP(){
  if(!currentUser)return;
  const doc=await db.collection("vip_users").doc(currentUser.uid).get();
  if(doc.exists){
    const data=doc.data();
    if(!data.expiresAt || data.expiresAt.toDate()>new Date()) return true;
  }
  return false;
}

function showVIP(){$("vipModal").classList.remove("hidden")}
function closeVIP(){$("vipModal").classList.add("hidden")}
async function requestVIP(){
  if(!currentUser)return;
  await db.collection("vip_requests").doc(currentUser.uid).set({
    uid:currentUser.uid,email:currentUser.email,status:"pending",
    createdAt:firebase.firestore.FieldValue.serverTimestamp()
  });
  alert("VIP request yoherejwe. Admin azagenzura payment.");
  closeVIP();
}

async function downloadVIP(fileId){
  if(!await checkVIP()){alert("❌ Download iyi ni iya VIP gusa.");return}
  downloadMovie(fileId);
}
function downloadMovie(fileId){
  if(!fileId || fileId.startsWith("FILE_ID")){alert("Admin agomba gushyiramo Google Drive file ID nyayo.");return}
  window.open("https://drive.google.com/uc?id="+encodeURIComponent(fileId)+"&export=download","_blank");
}
function watchMovie(fileId,isVIP){
  if(!fileId || fileId.startsWith("FILE_ID")){alert("Film source ntabwo irashyirwaho.");return}
  if(isVIP){
    checkVIP().then(ok=>{
      if(!ok){alert("🔒 Iyi film ni VIP. Iyandikishe kuri 300 RWF / week.");return}
      openPlayer(fileId);
    });
  }else openPlayer(fileId);
}
function openPlayer(fileId){
  $("playerModal").classList.remove("hidden");
  $("movieFrame").src="https://drive.google.com/file/d/"+encodeURIComponent(fileId)+"/preview";
}
function closePlayer(){$("movieFrame").src="";$("playerModal").classList.add("hidden")}

// ---------------- AI ----------------
function addChat(text,type){
  const d=document.createElement("div"); d.className="msg "+type; d.innerText=text;
  $("chat").appendChild(d); $("chat").scrollTop=$("chat").scrollHeight;
}
async function askAI(custom){
  const text=(custom||$("aiInput").value).trim();
  if(!text)return;
  addChat(text,"user"); $("aiInput").value="";
  addChat("⏳ AI iratekereza...","ai");
  try{
    const r=await fetch("/api/ai",{method:"POST",headers:{"Content-Type":"application/json"},
      body:JSON.stringify({message:text,movies:movies.map(m=>({title:m.title,genre:m.genre,translator:m.translator,vip:!!m.vip}))})});
    const data=await r.json();
    const last=[...$("chat").children].pop(); last.innerText=data.reply||"AI ntiyabonetse.";
  }catch(e){
    const last=[...$("chat").children].pop();
    last.innerText="AI ntiri gukora. Reba ko server iri gukora kandi OPENAI_API_KEY yashyizwe muri .env.";
  }
}
function aiRecommend(){askAI("Mpa recommendation ya film nziza iri muri uru rubuga, kandi umbwire impamvu wayihisemo.");}

function escapeHtml(s){return String(s??"").replace(/[&<>"']/g,m=>({"&":"&amp;","<":"&lt;",">":"&gt;",'"':"&quot;","'":"&#039;"}[m]))}
function safe(s){return String(s??"").replace(/'/g,"\\'")}

const ads=[
"📢Kwamamaza hano | +250 792 552 013",
"⭐ VIP 300 RWF / 7 days via MTN MoMo",
"🎬 AGASOBANUYE — Shakisha film ukoresheje AI!"
];
function showAd(){$("dynamicAd").innerText=ads[Math.floor(Math.random()*ads.length)]}
showAd();setInterval(showAd,10000);
